export const SERVICES = [
  { id: "lips", name: "Modelowanie ust", price: 700 },
  { id: "botox", name: "Toksyna botulinowa", price: 650 },
  { id: "meso", name: "Mezoterapia", price: 400 },
  { id: "fillers", name: "Wypełniacze", price: 900 },
];