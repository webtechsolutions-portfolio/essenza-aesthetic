export const brand = {
  name: "Essenza Aesthetic",
  city: "Kielcach",
  phone: "+48 600 000 000",
  address: "ul. Przykładowa 1, Kielce",
};
